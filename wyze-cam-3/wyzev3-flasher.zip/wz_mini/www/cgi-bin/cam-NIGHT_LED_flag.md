Night Vision IR Lights Far (1=Far, 2=Off or Near)
