Timezone offset from GMT
