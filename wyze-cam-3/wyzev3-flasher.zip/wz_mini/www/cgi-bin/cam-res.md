(1=SD or HD, 2=360p)
