Use as a USB Video Class (UVC) Web Camera for your PC is supported. I have tested with Windows 10, Linux, and Android TV, and it appears as a Generic HD Camera. Audio is supported. This mode disables all other functionality, and only works as a USB Web Camera for your PC. Experimental. Note that the cables typically included with the camera do not data, use a known working micro-usb cable which supports data.

Supported modes: MJPG,Video 360p/720p/1080p

WEB_CAM_ENABLE="true"
WEB_CAM_BIT_RATE="8000"
WEB_CAM_FPS_RATE="25"
