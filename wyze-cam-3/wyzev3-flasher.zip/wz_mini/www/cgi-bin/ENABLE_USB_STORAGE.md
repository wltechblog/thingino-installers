USB Mass Storage Support:

ENABLE_USB_STORAGE="true"
If you would like to mount an EXT3/4 filesystem, also change:

ENABLE_EXT4="true"
