ENABLE_MP4_WRITE="false"
Forces the camera to skip writing files to /tmp, and write them directly to your storage medium or network mount, prevents trashing. Normally videos are written to /tmp then moved using mv, which can overload camera and or remote network connections. Useful for NFS/CIFS remote video storage.


