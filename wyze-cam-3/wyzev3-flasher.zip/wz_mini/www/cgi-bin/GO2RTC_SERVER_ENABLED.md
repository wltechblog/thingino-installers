GO2RTC_SERVER provide an alternative way to do RTSP and streaming to web!
