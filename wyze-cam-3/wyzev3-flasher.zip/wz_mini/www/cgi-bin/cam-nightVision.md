Night Vision Mode (1=On, 2=Off, 3=Auto)
