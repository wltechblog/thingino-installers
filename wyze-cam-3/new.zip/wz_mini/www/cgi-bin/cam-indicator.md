Camera Status Light (1=Enabled, 2=Disabled)
