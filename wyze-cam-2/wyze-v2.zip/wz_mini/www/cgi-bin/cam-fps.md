Frames Per Second
