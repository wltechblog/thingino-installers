Nightvision Conditions (1=Dusk, 2=Dark)
