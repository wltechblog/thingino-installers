Motion Box (1=Enabled, 2=Disabled)
